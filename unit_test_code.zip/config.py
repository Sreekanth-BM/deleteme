#logfile name (configdir+timestamp+logfilename)
# configdir=r"C:\Users\Desktop\prasanna"
# logfilename="awss3.log"
region_cw = 'us-east-1'

#aws
key="AKIAZKLRPDRESFPYBIGF" 
secret="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"

#s3
# foldername=""
regions3="us-east-1"
# seq_token = "49629618204817323473244898689365425892817479536679583970"
seq_token = None

#sqs
regionsqs="us-east-1"
# deadqueue="arn:aws:sqs:us-west-1:640724966473:test.fifo"
# queryurl="https://sqs.us-west-1.amazonaws.com/640724966473/test.fifo"

# test
queryurl = "https://sqs.us-east-1.amazonaws.com/496393795131/alpaca-s3-objects-test-pb.fifo"
