'''
sqs needs to have file names across s3 buckets
write errors into dead queue
logging to cloud watch
code needs to be unit tested

'''
from unicodedata import name
import boto3
import json
import config as c
import time
import os.path


def connectaws(service, region, key, secret):
     return boto3.client(service, region_name=region, aws_access_key_id=key, aws_secret_access_key=secret)


def fetch_files_s3(service, region, key, secret):
    s3=connectaws(service, region, key, secret)
    s3_buckets = s3.list_buckets()['Buckets']
    all_files = list()
    for each in s3_buckets:
        files = s3.list_objects(Bucket=each['Name'])['Contents']
        names = [file['Key'] for file in files]
        all_files.extend(names)    
    return all_files


def sendtosqs(service, region, data,  key, secret, queryurl):
    sqs_client=connectaws(service, region, key, secret)
    message = {"data": data}
    # Send a message to existing SQS
    sent_response = sqs_client.send_message(
        QueueUrl=queryurl,
        MessageBody=json.dumps(message),
        MessageGroupId='test',
        MessageDeduplicationId='test'
    )
    return sent_response
    # Send logs to CloudWatch
    # sendtoCW(json.dumps(sent_response))



def sendtoCW(message):
    cw_client=connectaws('logs', c.region_cw)
    # Sending s3-sqs logs to Cloudwatch
    log_event = {
        'logGroupName': '/aws/lambda/lambda-s3-trigger',
        'logStreamName': 'S3toSQS',
        'logEvents': [
            {
                'timestamp': int(round(time.time() * 1000)),
                'message': message
            },
        ],
    }
    
    seq_token = "49623780465957071784024290034919717000033508025731909090"
    
    if os.path.isfile('/tmp/seq_token.txt'):
        seq_token = open('/tmp/seq_token.txt').read().strip()

    if seq_token:
        log_event['sequenceToken'] = seq_token

    response = cw_client.put_log_events(**log_event)
    
    open('/tmp/seq_token.txt','w').write(response['nextSequenceToken'])
    print("Sent logs to CW")


def main_handler(event, handler):
    data=fetch_files_s3("s3", c.regions3)
    print("Files are ",data)
    sendtosqs("sqs", c.regionsqs, data, c.queryurl)
    
