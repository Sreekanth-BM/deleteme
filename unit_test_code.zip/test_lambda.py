import unittest
from main import *
# import inspect
import config as c

class PBTest(unittest.TestCase):
    def test_connection(self):
        print("Test case : S3 Connectivity")
        connection = connectaws("s3", c.region_cw, c.key, c.secret)
        print(connection)
        self.assertIsNotNone(connection)
    
    def test_connections3v2(self):
        print("Test case : SQS Connectivity")
        connection = connectaws("sqs", c.regionsqs, c.key, c.secret)
        self.assertIsNotNone(connection)
    
    def test_listfiles(self):
        print("Test case : Read files from S3")
        result = fetch_files_s3("s3", c.regions3, c.key, c.secret)
        print(result)
        self.assertEqual(isinstance(result,list),(True or None))

    def test_message_status(self):
        print("Test case : Check messsage been sent to SQS or not")
        result = sendtosqs("sqs", c.regionsqs, "dumy message", c.key, c.secret, c.queryurl)
        print(result)
        # self.assertEqual(isinstance(result,list),(True or None))    

unittest.main()
